BOXING ARENA 3D — Android Studio project

Бұл ZIP — дайын APK емес, APK құрастыруға арналған Android Studio жобасы.
APK-ны жасау үшін:
1. ZIP-ті шығарып ал.
2. Android Studio-ны ашып, осы BoxingArena3D бумасын Open арқылы таңда.
3. Gradle Sync аяқталғанын күт.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) таңда.
5. APK app/build/outputs/apk/debug/ ішінде пайда болады.

Ескерту:
- Three.js және cannon-es кітапханалары CDN арқылы жүктеледі, сондықтан бірінші іске қосқанда интернет керек.
- Бұл бастапқы ойын прототипі; толық UFC 5 деңгейіндегі графика емес.
