BoxingArena3D — GitHub Actions APK builder

IMPORTANT:
This folder contains the GitHub Actions workflow only. It is NOT the game project
and does not contain a compiled APK.

How to use it on your phone:
1. Extract your original BoxingArena3D_Android_Project.zip.
2. In your GitHub repository, upload the CONTENTS of the extracted project
   (the folders app/ and files such as build.gradle and settings.gradle).
   Do not upload the original ZIP as a single nested file.
3. Upload the .github folder from this package into the repository root.
4. Commit the files to the main branch.
5. Open the repository's Actions tab.
6. Select "Build BoxingArena3D APK" and press "Run workflow" if it did not start
   automatically after the commit.
7. Wait for the workflow to finish successfully.
8. Open the completed run and download the artifact named
   "BoxingArena3D-debug-apk". It contains the debug APK.

Notes:
- The project must contain app/build.gradle, root build.gradle, and settings.gradle.
- The workflow uses Java 17 and Gradle 8.9.
- If the build fails, copy the red error text from the Actions log and share it.
- A successful debug APK may need permission to install from the browser/files app.
